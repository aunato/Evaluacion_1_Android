package com.example.app_nueva;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        recyclerView = (RecyclerView)  findViewById(R.id.recyclerView);
        itemAdapter = new ItemAdapter(this);


        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        itemAdapter.setData(getData());
        recyclerView.setAdapter(itemAdapter);
        recyclerView.setLayoutManager(linearLayoutManager);
    }

    private List<Item> getData() {
        List<Item> list = new ArrayList<>();
        list.add(new Item(R.drawable.appstore, "appstore"));
        list.add(new Item(R.drawable.instagram, "Instagram"));
        list.add(new Item(R.drawable.chrome, "Google Chrome"));
        list.add(new Item(R.drawable.imusic, "Imusic"));
        list.add(new Item(R.drawable.linkedin, "Linkedin"));
        list.add(new Item(R.drawable.paypal, "Paypal"));
        list.add(new Item(R.drawable.pinterest, "Pinterest"));
        list.add(new Item(R.drawable.twiter, "Twitter"));
        list.add(new Item(R.drawable.appstore, "appstore"));
        list.add(new Item(R.drawable.instagram, "Instagram"));
        list.add(new Item(R.drawable.chrome, "Google Chrome"));
        list.add(new Item(R.drawable.imusic, "Imusic"));
        list.add(new Item(R.drawable.linkedin, "Linkedin"));
        list.add(new Item(R.drawable.paypal, "Paypal"));
        list.add(new Item(R.drawable.pinterest, "Pinterest"));
        list.add(new Item(R.drawable.twiter, "twitter"));

        return list;

    }
}